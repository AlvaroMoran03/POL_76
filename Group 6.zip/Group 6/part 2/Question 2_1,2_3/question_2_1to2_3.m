clear; clc;
%% Question 1
%Download and process data

M2  = readtable('raw data/M2REAL.xlsx');
GDP = readtable('raw data/GDPC1.xlsx');
DFF = readtable('raw data/DFF.xlsx');
CPI = readtable('raw data/CPIAUCSL.xlsx');



%%% DFF
DFF.observation_date = datetime(DFF.observation_date, 'InputFormat', 'yyyy-MM-dd');

DFF_filtered = DFF(DFF.observation_date >= datetime(1985,1,1) & DFF.observation_date <= datetime(2007,1,1), :);

DFF_tt = table2timetable(DFF_filtered, 'RowTimes', 'observation_date');

DFF_quarterly = retime(DFF_tt, 'quarterly', 'mean');

DFF_quarterly.observation_date = DFF_quarterly.observation_date + calmonths(3);

DFF_final = timetable2table(DFF_quarterly);
DFF_final = renamevars(DFF_final, 'DFF', 'dff');
disp(DFF_final);

%%% CPI

CPI.observation_date = datetime(CPI.observation_date, 'InputFormat', 'yyyy-MM-dd');

CPI_filtered = CPI(ismember(month(CPI.observation_date), [4, 7, 10, 1]), :);

CPI_filtered.cpi = [NaN; diff(CPI_filtered{:,2}) ./ CPI_filtered{1:end-1,2} * 100];

CPI_final = CPI_filtered(CPI_filtered.observation_date >= datetime(1985,4,1) & CPI_filtered.observation_date <= datetime(2007,1,1), :);

disp(CPI_final);
%%% M2

M2.observation_date = datetime(M2.observation_date, 'InputFormat', 'yyyy-MM-dd');

M2_filtered = M2(day(M2.observation_date) == 1 & ismember(month(M2.observation_date), [4, 7, 10, 1]), :);

M2_filtered.m2 = [NaN; diff(M2_filtered{:,2}) ./ M2_filtered{1:end-1,2} * 100];

M2_final = M2_filtered(2:end, :);

M2_final = M2_final(M2_final.observation_date >= datetime(1985,4,1) & M2_final.observation_date <= datetime(2007,1,1), :);

disp(M2_final);
%%% GDP
GDP.observation_date = datetime(GDP.observation_date, 'InputFormat', 'yyyy-MM-dd');

GDP.gdp = [NaN; diff(GDP{:,2}) ./ GDP{1:end-1,2} * 100];

disp(head(GDP));
GDP_final = GDP(GDP.observation_date >= datetime(1985,4,1) & GDP.observation_date <= datetime(2007,1,1), :);

disp(GDP_final);
%%% Final
merged_df = innerjoin(GDP_final, CPI_final, 'Keys', 'observation_date');
merged_df = innerjoin(merged_df, M2_final, 'Keys', 'observation_date');
merged_df = innerjoin(merged_df, DFF_final, 'Keys', 'observation_date');



final = merged_df(:, {'observation_date', 'gdp', 'cpi', 'dff', 'm2'});

numericMatrix = table2array(final(:, {'gdp', 'cpi', 'dff', 'm2'}));

variableNames = {'gdp', 'cpi', 'dff', 'm2'};

finalData = struct();
for i = 1:length(variableNames)
    finalData.(variableNames{i}) = numericMatrix(:, i);
end

save('data2.mat', '-struct', 'finalData');
%%% Plot
dates = final.observation_date;
GDP = final.gdp;
CPI = final.cpi;
DFF = final.dff;
M2 = final.m2;

num_xticks = 8;  
tick_positions = round(linspace(1, length(dates), num_xticks));
tick_labels = dates(tick_positions);  

figure;

subplot(2,2,1);
plot(dates, GDP, 'b', 'LineWidth', 1.5);
title('Real GDP Growth (QoQ)', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('Quarter', 'FontSize', 12);
ylabel('Percentage Change', 'FontSize', 12);
grid on;
xticks(tick_labels);
xticklabels(datestr(tick_labels - calmonths(3), 'QQ-YYYY')); 
xtickangle(45);

subplot(2,2,2);
plot(dates, CPI, 'b', 'LineWidth', 1.5);
title('Consumer Price Index (CPI) Growth (QoQ)', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('Quarter', 'FontSize', 12);
ylabel('Percentage Change', 'FontSize', 12);
grid on;
xticks(tick_labels);
xticklabels(datestr(tick_labels - calmonths(3), 'QQ-YYYY'));  
xtickangle(45);

subplot(2,2,3);
plot(dates, DFF, 'b', 'LineWidth', 1.5);
title('Federal Funds Effective Rate', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('Quarter', 'FontSize', 12);
ylabel('Percentage', 'FontSize', 12);
grid on;
xticks(tick_labels);
xticklabels(datestr(tick_labels - calmonths(3), 'QQ-YYYY'));  
xtickangle(45);

subplot(2,2,4);
plot(dates, M2, 'b', 'LineWidth', 1.5);
title('M2 Money Stock Growth (QoQ)', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('Quarter', 'FontSize', 12);
ylabel('Percentage Change', 'FontSize', 12);
grid on;
xticks(tick_labels);
xticklabels(datestr(tick_labels - calmonths(3), 'QQ-YYYY'));  
xtickangle(45);

%sgtitle('Macroeconomic Indicators: Quarter-on-Quarter Growth', 'FontSize', 16, 'FontWeight', 'bold');
set(gcf, 'PaperPositionMode', 'auto');
set(gcf, 'Position', [100, 100, 1400, 900]);

if ~exist('graphs 2', 'dir')
    mkdir('graphs 2');
end

saveas(gcf, 'graphs 2/variables.png');

%% Question 2

% Cargar el archivo .mat
load('data2.mat');

info = whos('-file', 'data2.mat');

disp('Nombres de las variables en el archivo data2.mat:');
disp({info.name});
%% Question 2a
data = [gdp cpi];

p = 4;                  % p: order of VAR(p)
[T, k] = size(data);    % T: number of observations, k: number of variables

% Construct X for Y=XB+e
X = zeros(T-p, k*p);
for i = 1:p
    X(:, k*(i-1)+1:k*i) = data(p+1-i:T-i, :);
end

X = [ones(T-p, 1) X];
Y = data(p+1:end, :);
ndet=1;                      
% Estimation
Beta = inv(X'*X) * X'*Y;
e = Y - X*Beta;

% Estimated variance-covariance matrix
Omega = e'*e/(T-p);

% Coeficients matrix
Beta
%variance matrix
Omega

%% Question 2b


% alpha that makes the denominator equal to zero
alpha_0 = Omega(2, 1)/Omega(2, 2);

alpha_1 = linspace(alpha_0 - 4, alpha_0, 1000);
alpha_2 = linspace(alpha_0, alpha_0 + 4, 1000);
identified_set_1 = identified_set(alpha_1, Omega);
identified_set_2 = identified_set(alpha_2, Omega);

subplot(1, 1, 1)
plot(alpha_1, identified_set_1, 'Color', "black", "LineWidth", 3)
hold on
plot(alpha_2, identified_set_2, "Color", "black", "LineWidth", 3)
yline(0,'k--')
title("The function \beta(\alpha)", 'interpreter', 'tex', 'fontsize', 11)
xlabel("\alpha", 'interpreter', 'tex', 'fontsize', 11)
ylabel("\beta", 'interpreter', 'tex', 'fontsize', 11)
xlim([alpha_0-4 alpha_0+4])
ylim([-30 30])
grid on
%compute structural parameters
P = chol(Omega)';
D = eye(2);
D(1, 1) = P(1, 1)^2;
D(2, 2) = P(2, 2)^2;
A_0 = D^.5*inv(P);     %matrix of structural parameters
beta_chol = -A_0(2,2)/A_0(2,1);

scatter(0, beta_chol, 300, 'filled', "red", "pentagram")
legend('', '', '', 'Cholesky identified', 'FontSize', 12)
if ~exist('graphs 2', 'dir')
    mkdir('graphs 2');
end

saveas(gcf, 'graphs 2/2_2_b_possible_values.png');


%% Question 3a. Trivariate VAR(4) model

% Adding Federal Funds Rate to the bivariate Model


load('data2.mat');

info = whos('-file', 'data2.mat');

disp('Nombres de las variables en el archivo data2.mat:');
disp({info.name});
%%% a)
data = [gdp cpi dff];                      
%model setup
const=ones(size(data,1),1);   %adding a deterministic term (constant)
ndet=1;                       %number of deterministic variables (1 constant)
data=[const data];
[sp,nvars]=size(data);   %sp is the total number of observations, in this case sp=88 and nvars = 3
nvars=nvars-ndet;        %the '-ndet' takes out the counting of deterministic variables
nlags=4;                %number of lags, in this case is 4

ess=sp-nlags;       %effective sample size after taking lags into account
sb=nlags+1;         %sample beginning
sl=sp;              %last period of sample
ncoe=nvars*nlags;   %number of coefficients without deterministic variables (n*m) (3*4 = 12)

% Now we construct X for the reduced form of the VAR (4).

x=data(:,ndet+1:end);
X=zeros(ess,ncoe);  %TxK where T = ess and K = ncoe without constants.
for k=1:nlags
    X(:,nvars*(k-1)+1:nvars*k) = x(sb-k:sl-k,:);
end
X=[ones(ess,1) X];   %without trend

% Estimation

y=x(sb:sl,:);
xtx=X'*X;
xty=X'*y;

% OLS estimation of reduced-form coefficients

PHI_trivariate=inv(X'*X)*X'*y;
e_trivariate=y-X*PHI_trivariate;

% Variance-covariance matrix 

omega_trivariate=e_trivariate'*e_trivariate/ess;

omega_trivariate %Reporting the matrix variance covariance of the reduced form errors.

% Matrix PHI of coeficients of the reduced form.

PHI_trivariate

% Defining the parameters
n = size(omega_trivariate, 1); % Number of endogenous variables

% Using varcompanion function to generate the companion matrix
F = varcompanion(PHI_trivariate', ndet, n, nlags);

% Verifying stability of VAR(4) with eigenvalues
eigvals = eig(F);

% Results of the stability of the model
disp('VAR Eigenvalues:');
disp(eigvals);

if all(abs(eigvals) < 1)
    disp('VAR(4) trivariate model is stable.');
else
    disp('VAR(4) trivariate model is unstable.');
end

% Eigenvalues
figure;
theta = linspace(0, 2*pi, 100);
plot(cos(theta), sin(theta), 'k--'); hold on; % Unit circle
scatter(real(eigvals), imag(eigvals), 'ro', 'filled'); % Eigenvalues
%title('Stability Check: Eigenvalues of the Companion Matrix');
xlabel('Real Part','FontSize',12);
ylabel('Imaginary Part','FontSize',12);
grid on;
axis equal;
if ~exist('graphs 2', 'dir')
    mkdir('graphs 2');
end

saveas(gcf, 'graphs 2/estability check.png')
%% Question 3b: Cholesky decomposition for identification

% Cholesky decomposition
H_trivariate = chol(omega_trivariate)';

% IRF function
nsteps = 17;     % horizon for impulse responses 
irf_trivariate = impulse(PHI_trivariate', H_trivariate, ndet, nlags, nsteps);

% Impulse responses of one-standard-deviation shocks by monetary policy
shock_interest_output = squeeze(irf_trivariate(1,3,:))';  % GDP response
shock_interest_inflation = squeeze(irf_trivariate(2,3,:))'; % Inflation response
shock_interest_rate = squeeze(irf_trivariate(3,3,:))';  % Fed Funds Rate response

% Graphs of structural IRFs
h = (0:1:nsteps)';

figure;
subplot(3,1,1);
plot(h, shock_interest_output, 'b', 'LineWidth', 2); grid on;
title('GDP growth rate response after a monetary policy shock');
ylabel('Change in GDP (%)');

subplot(3,1,2);
plot(h, shock_interest_inflation, 'b', 'LineWidth', 2); grid on;
title('Inflation response');
ylabel('Change in inflation (%)');

subplot(3,1,3);
plot(h, shock_interest_rate, 'b', 'LineWidth', 2); grid on;
title('Fed Funds Rate response after a monetary policy shock');
ylabel('Change in rate (%)');
xlabel('Horizon(quarters)');

if ~exist('graphs 2', 'dir')
    mkdir('graphs 2');
end

saveas(gcf, 'graphs 2/IFF 3_b .png')

%% Question 3c: Finding the implied Taylor Rule.

%Finding the structural A: 

%compute structural parameters
D=eye(3);
D(1,1)=H_trivariate(1,1)^2;
D(2,2)=H_trivariate(2,2)^2;
D(3,3)=H_trivariate(3,3)^2;
A=D^.5*inv(H_trivariate)     %matrix of structural parameters

% Third row to extract implied Taylor Rule:

tercera_fila = A(3, 1:2);

% Mostrar los coeficientes de la tercera fila
disp('Taylor rule coeficients on output and inflation');
disp(tercera_fila);
