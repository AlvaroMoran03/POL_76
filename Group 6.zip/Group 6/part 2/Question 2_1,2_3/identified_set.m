function beta = identified_set(alpha, Omega)
    beta = zeros(size(alpha));
    for a=1:numel(alpha)
        beta(a) = (Omega(1, 1) - alpha(a)*Omega(2,1))/(Omega(2,1) - alpha(a)*Omega(2,2));
    end
end

