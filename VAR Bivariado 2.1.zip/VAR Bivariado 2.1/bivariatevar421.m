%%% VAR (4) - Extension Course of Advanced Economics
%%%Bivariate VAR
clear;
clc;

try
    macrovariablesbase = readmatrix('macrovariablesbase.txt');
catch
    error('No se pudo cargar el archivo macrovariablesbase.txt. Verifica la ubicación y el formato.');
end
% This dataset contains the quarterly variables REALGDP, Consumer Price
% Index, M2 money stock and Effective Federal Funds Rate.
%For bivariate VAR purpouses, we will consider only 2 endogenous variables.

realgdp=macrovariablesbase(:,1);
cpi=macrovariablesbase(:,2);
data=[realgdp cpi];
                   
const=ones(size(data,1),1);   %adding a deterministic term (constant)
ndet=1;                       %number of deterministic variables (1 constant)
data=[const data];

%nsteps=6;    %If we want to calculate impulse responses, horizon                       
   
%model setup

[sp,nvars]=size(data);   %sp is the total number of observations, in this case sp=88 and nvars = 3
nvars=nvars-ndet;        %the '-ndet' takes out the counting of deterministic variables
nlags=4;                %number of lags, in this case is 4

ess=sp-nlags;       %effective sample size after taking lags into account
sb=nlags+1;         %sample beginning
sl=sp;              %last period of sample
ncoe=nvars*nlags;   %number of coefficients without deterministic variables (n*m) (2*4 = 8)

%Now we construct X for the reduced form of the VAR (4).

x=data(:,ndet+1:end);
X=zeros(ess,ncoe);  %TxK where T = ess and K = ncoe without constants.
for k=1:nlags
    X(:,nvars*(k-1)+1:nvars*k) = x(sb-k:sl-k,:);
end
X=[ones(ess,1) X];   %without trend

%estimation

y=x(sb:sl,:);
xtx=X'*X;
xty=X'*y;
%OLS estimation of reduced-form coefficients

PHI=inv(X'*X)*X'*y;
e=y-X*PHI;

%variance-covariance matrix 

omega=e'*e/ess;

omega %Reporting the matrix variance covariance of the reduced form errors.

%Matrix PHI of coeficients of the reduced form.

PHI

