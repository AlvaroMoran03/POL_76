function save_pdf(f,filename,x)
% SYNTAX
% save_pdf(f,filename,x)

set(f, 'PaperPosition', [0 0 4.9 2.9]*x);
set(f,'PaperSize',[4.9 2.9]*x) % wide * hight
saveas(f,filename);



