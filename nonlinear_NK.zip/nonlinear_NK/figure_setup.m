map = colormap(winter(3));
set(0,'DefaultLineLineWidth',1);
set(0,'defaultAxesLineStyleOrder','-|-.|:|-o|--o|:o|-^|--^|:^');
set(0,'defaulttextinterpreter','LaTex');
set(0,'defaultAxesColorOrder',map);
set(0,'DefaultAxesFontSize',6);
set(0,'DefaultTextFontSize',6);
set(0,'DefaultAxesFontName','Helvetica');
set(0,'DefaultTextFontName','Helvetica');
% set(0,'DefaultUipanelFontName','Helvetica');
set(0,'DefaultTextFontWeight','normal');
set(0,'defaulttextinterpreter','LaTex');
set(0,'DefaultLegendInterpreter','LaTex')
close all;

