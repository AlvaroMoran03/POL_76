function [R_SS,pibar_SS,A_SS,pstar_SS,K_SS,F_SS,N_SS,C_SS] = steadysCALVO(nbeta,epsil,phi,nu,pitarget,theta,phi_pie,phi_x)

if pitarget ~= 1
   error('pitarget needs to be 1'); 
end
        
A_SS=1;
N_SS=1;
pibar_SS=1;
pstar_SS=1;
R_SS=1/nbeta;
F_SS = 1/(1-nbeta*theta);
K_SS = F_SS;
C_SS = N_SS;

err(1)=1/C_SS - (nbeta/C_SS)*(R_SS/pibar_SS);
err(2)=1 + (pibar_SS^(epsil-1))*nbeta*theta*F_SS -F_SS;
err(3)=C_SS - pstar_SS*A_SS*N_SS;
err(4)=F_SS*(((1-theta*pibar_SS^(epsil-1))/(1-theta))^(1/(1-epsil))) - K_SS;
err(5)=(1 - nu)*(epsil/(epsil-1))*C_SS*(N_SS^phi)/A_SS + nbeta*theta*(pibar_SS^epsil)*K_SS - K_SS;
err(6)=1/pstar_SS - ((1-theta)*(((1-theta*(pibar_SS)^(epsil-1))/(1-theta))^(epsil/(epsil-1))) + theta*(pibar_SS^epsil)/pstar_SS);
err(7)=R_SS/R_SS - exp(phi_pie*(pibar_SS-1) + phi_x*(log(C_SS/A_SS)) );
err(8)=log(A_SS) - (1.85*log(A_SS) - 0.855*log(A_SS));

if max(abs(err)) > .1e-10
    error('fatal (steadys) state state not satisfied')
end